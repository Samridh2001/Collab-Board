# Collab-Board <!--[[Visit]](https://algo-visualizer-f76e9.web.app/)-->

- Draw and talk with your peers at the same time
- Create a public board or save a private board with collaborators

![Auth](./screenshots/auth.jpg)

![Dashboard](./screenshots/dashboard.jpg)

![Board](./screenshots/board.jpg)